function ExecuteScript(strId)
{
  switch (strId)
  {
      case "65YSRrQHWwD":
        Script1();
        break;
  }
}

function Script1()
{
  window.print();
}

